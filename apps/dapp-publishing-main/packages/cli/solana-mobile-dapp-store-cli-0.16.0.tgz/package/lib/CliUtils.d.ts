import type { Connection } from "@solana/web3.js";
import { Keypair } from "@solana/web3.js";
import debugModule from "debug";
import { Metaplex } from "@metaplex-foundation/js";
export declare class Constants {
    static CLI_VERSION: string;
    static CONFIG_FILE_NAME: string;
    static DEFAULT_RPC_DEVNET: string;
    static DEFAULT_PRIORITY_FEE: number;
    static getConfigFilePath: () => string;
}
export declare const debug: debugModule.Debugger;
export declare const checkForSelfUpdate: () => Promise<void>;
export declare const checkMintedStatus: (conn: Connection, appAddr: string, releaseAddr: string) => Promise<void>;
export declare const sleep: (ms: number) => Promise<void>;
export declare const parseKeypair: (pathToKeypairFile: string) => Keypair | undefined;
export declare const isDevnet: (rpcUrl: string) => boolean;
export declare const isTestnet: (rpcUrl: string) => boolean;
export declare const checkSubmissionNetwork: (rpcUrl: string) => void;
export declare const generateNetworkSuffix: (rpcUrl: string) => string;
export declare const dryRunSuccessMessage: () => void;
export declare const alphaAppSubmissionMessage: () => void;
export declare const showNetworkWarningIfApplicable: (rpcUrl: string) => void;
export declare const showMessage: (titleMessage?: string, contentMessage?: string, type?: "standard" | "error" | "warning") => string;
export declare const getMetaplexInstance: (connection: Connection, keypair: Keypair, storageParams?: string) => Metaplex;
//# sourceMappingURL=CliUtils.d.ts.map