import { Keypair } from "@solana/web3.js";
type CreateAppCommandInput = {
    signer: Keypair;
    url: string;
    dryRun?: boolean;
    storageParams: string;
    priorityFeeLamports: number;
};
export declare const createAppCommand: ({ signer, url, dryRun, storageParams, priorityFeeLamports, }: CreateAppCommandInput) => Promise<{
    appAddress: string;
    transactionSignature: string;
} | undefined>;
export {};
//# sourceMappingURL=CreateCliApp.d.ts.map