import { type Metaplex, type TransactionBuilder } from "@metaplex-foundation/js";
export declare function sendAndConfirmTransaction(metaplex: Metaplex, builder: TransactionBuilder): ReturnType<TransactionBuilder["sendAndConfirm"]>;
//# sourceMappingURL=utils.d.ts.map