import { Keypair } from "@solana/web3.js";
type PublishUpdateCommandInput = {
    appMintAddress: string;
    releaseMintAddress: string;
    signer: Keypair;
    url: string;
    dryRun: boolean;
    compliesWithSolanaDappStorePolicies: boolean;
    requestorIsAuthorized: boolean;
    critical: boolean;
    alphaTest?: boolean;
};
export declare const publishUpdateCommand: ({ appMintAddress, releaseMintAddress, signer, url, dryRun, compliesWithSolanaDappStorePolicies, requestorIsAuthorized, critical, alphaTest, }: PublishUpdateCommandInput) => Promise<void>;
export {};
//# sourceMappingURL=PublishCliUpdate.d.ts.map