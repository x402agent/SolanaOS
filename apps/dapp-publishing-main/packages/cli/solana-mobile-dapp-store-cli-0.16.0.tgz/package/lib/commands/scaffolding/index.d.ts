export * from "./ScaffoldInit.js";
//# sourceMappingURL=index.d.ts.map