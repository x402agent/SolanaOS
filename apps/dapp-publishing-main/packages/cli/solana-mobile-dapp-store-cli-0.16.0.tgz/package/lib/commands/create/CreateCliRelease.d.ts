import { Keypair } from "@solana/web3.js";
type CreateReleaseCommandInput = {
    appMintAddress: string;
    buildToolsPath: string;
    signer: Keypair;
    url: string;
    dryRun?: boolean;
    storageParams: string;
    priorityFeeLamports: number;
};
export declare const createReleaseCommand: ({ appMintAddress, buildToolsPath, signer, url, dryRun, storageParams, priorityFeeLamports, }: CreateReleaseCommandInput) => Promise<{
    releaseAddress: string;
    transactionSignature: string;
} | undefined>;
export {};
//# sourceMappingURL=CreateCliRelease.d.ts.map