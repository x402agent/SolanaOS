import { Keypair } from "@solana/web3.js";
type PublishSupportCommandInput = {
    appMintAddress: string;
    releaseMintAddress: string;
    signer: Keypair;
    url: string;
    dryRun: boolean;
    requestorIsAuthorized: boolean;
    requestDetails: string;
};
export declare const publishSupportCommand: ({ appMintAddress, releaseMintAddress, signer, url, dryRun, requestorIsAuthorized, requestDetails, }: PublishSupportCommandInput) => Promise<void>;
export {};
//# sourceMappingURL=PublishCliSupport.d.ts.map