import type { Keypair } from "@solana/web3.js";
export declare const validateCommand: ({ signer, buildToolsPath, }: {
    signer: Keypair;
    buildToolsPath?: string;
}) => Promise<void>;
//# sourceMappingURL=ValidateCommand.d.ts.map