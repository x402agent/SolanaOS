import { Keypair } from "@solana/web3.js";
type PublishRemoveCommandInput = {
    appMintAddress: string;
    releaseMintAddress: string;
    signer: Keypair;
    url: string;
    dryRun: boolean;
    requestorIsAuthorized: boolean;
    critical: boolean;
};
export declare const publishRemoveCommand: ({ appMintAddress, releaseMintAddress, signer, url, dryRun, requestorIsAuthorized, critical, }: PublishRemoveCommandInput) => Promise<void>;
export {};
//# sourceMappingURL=PublishCliRemove.d.ts.map