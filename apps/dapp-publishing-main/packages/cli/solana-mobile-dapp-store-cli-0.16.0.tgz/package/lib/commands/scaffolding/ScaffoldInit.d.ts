export declare const initScaffold: () => string;
//# sourceMappingURL=ScaffoldInit.d.ts.map