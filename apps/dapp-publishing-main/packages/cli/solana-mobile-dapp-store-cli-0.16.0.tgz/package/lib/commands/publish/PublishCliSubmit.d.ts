import { Keypair } from "@solana/web3.js";
type PublishSubmitCommandInput = {
    appMintAddress: string;
    releaseMintAddress: string;
    signer: Keypair;
    url: string;
    dryRun: boolean;
    compliesWithSolanaDappStorePolicies: boolean;
    requestorIsAuthorized: boolean;
    alphaTest?: boolean;
};
export declare const publishSubmitCommand: ({ appMintAddress, releaseMintAddress, signer, url, dryRun, compliesWithSolanaDappStorePolicies, requestorIsAuthorized, alphaTest }: PublishSubmitCommandInput) => Promise<void>;
export {};
//# sourceMappingURL=PublishCliSubmit.d.ts.map