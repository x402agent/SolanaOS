export {};
//# sourceMappingURL=contentGateway.test.d.ts.map