import type { Keypair } from "@solana/web3.js";
import type { MetaplexFile } from "@metaplex-foundation/js";
import { type StorageNetwork } from "./contentGateway.js";
type TurboServiceConfig = {
    gatewayUrl?: string;
    paymentServiceConfig?: {
        url: string;
    };
    uploadServiceConfig?: {
        url: string;
    };
};
export declare class TurboStorageDriver {
    private turbo;
    private bufferPercentage;
    private network;
    private uploadQueue;
    private isProcessingQueue;
    constructor(keypair: Keypair, network?: StorageNetwork, bufferPercentage?: number);
    getUploadPrice(bytes: number): Promise<bigint>;
    private withRetry;
    private formatInsufficientFundsError;
    private topUpCredits;
    private checkBalanceAndTopUp;
    private processQueue;
    upload(file: MetaplexFile): Promise<string>;
}
export declare const getTurboServiceConfig: (network: StorageNetwork) => TurboServiceConfig;
export {};
//# sourceMappingURL=TurboStorageDriver.d.ts.map