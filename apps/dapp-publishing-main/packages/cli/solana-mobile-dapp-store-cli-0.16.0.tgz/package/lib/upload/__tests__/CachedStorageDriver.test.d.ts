export {};
//# sourceMappingURL=CachedStorageDriver.test.d.ts.map