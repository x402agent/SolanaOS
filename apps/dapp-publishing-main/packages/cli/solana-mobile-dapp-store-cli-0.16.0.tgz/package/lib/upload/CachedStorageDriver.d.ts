import type { MetaplexFile, StorageDriver } from "@metaplex-foundation/js";
type URI = string;
type Asset = {
    path: string;
    sha256: string;
    uri: URI;
};
export type AssetManifestSchema = {
    schema_version: string;
    assets: {
        [path: string]: Asset;
    };
};
export declare class CachedStorageDriver implements StorageDriver {
    static readonly SCHEMA_VERSION = "0.1";
    assetManifest: AssetManifestSchema;
    assetManifestPath: string;
    storageDriver: StorageDriver;
    constructor(storageDriver: StorageDriver, { assetManifestPath }: {
        assetManifestPath: string;
    });
    getUploadPrice(bytes: number): Promise<import("@metaplex-foundation/js").Amount>;
    private resolveAssetManifestPath;
    private normalizeAsset;
    private normalizeAssetManifest;
    private writeAssetManifest;
    loadAssetManifest(filename: string): AssetManifestSchema | undefined;
    uploadedAsset(filename: string, { sha256 }: {
        sha256: string;
    }): Asset | null;
    upload(file: MetaplexFile): Promise<string>;
}
export {};
//# sourceMappingURL=CachedStorageDriver.d.ts.map