export type StorageNetwork = "devnet" | "mainnet";
export declare const buildPublicContentUrl: (id: string, network: StorageNetwork) => string;
export declare const normalizePublicContentUrl: (url: string) => string;
//# sourceMappingURL=contentGateway.d.ts.map