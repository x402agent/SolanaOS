import { AndroidDetails, App, LastSubmittedVersionOnChain, LastUpdatedVersionOnStore, Publisher, Release, SolanaMobileDappPublisherPortal } from "@solana-mobile/dapp-store-publishing-tools";
export interface PublishDetails {
    publisher: Publisher;
    app: App;
    release: Release;
    solana_mobile_dapp_publisher_portal: SolanaMobileDappPublisherPortal;
    lastSubmittedVersionOnChain: LastSubmittedVersionOnChain;
    lastUpdatedVersionOnStore: LastUpdatedVersionOnStore;
}
type SaveToConfigArgs = {
    app?: Pick<App, "address">;
    release?: {
        address?: Release["address"];
        android_details?: Partial<AndroidDetails>;
    };
    lastSubmittedVersionOnChain?: LastSubmittedVersionOnChain;
    lastUpdatedVersionOnStore?: LastUpdatedVersionOnStore;
};
export declare const loadPublishDetails: (configPath: string) => Promise<PublishDetails>;
export declare const loadPublishDetailsWithChecks: (buildToolsDir?: string | null) => Promise<PublishDetails>;
export declare const extractCertFingerprint: (aaptDir: string, apkPath: string) => Promise<string>;
export declare const writeToPublishDetails: ({ app, release, lastSubmittedVersionOnChain, lastUpdatedVersionOnStore }: SaveToConfigArgs) => Promise<void>;
export {};
//# sourceMappingURL=PublishDetails.d.ts.map