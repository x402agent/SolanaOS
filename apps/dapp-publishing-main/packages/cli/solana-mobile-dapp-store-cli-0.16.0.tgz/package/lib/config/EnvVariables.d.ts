export type S3Config = {
    accessKey: string;
    secretKey: string;
    bucketName: string;
    regionName: string;
};
export declare class EnvVariables {
    get hasAndroidTools(): boolean;
    get androidToolsDir(): string;
    get hasS3EnvArgs(): boolean;
    get s3Config(): S3Config;
    constructor();
}
//# sourceMappingURL=EnvVariables.d.ts.map