import { EnvVariables, S3Config } from "./EnvVariables.js";
export declare class S3StorageManager {
    private envVars;
    private _config;
    get hasS3Config(): boolean;
    get s3Config(): S3Config;
    constructor(envVars: EnvVariables);
    parseCmdArg(cmdArg: string): void;
}
//# sourceMappingURL=S3StorageManager.d.ts.map