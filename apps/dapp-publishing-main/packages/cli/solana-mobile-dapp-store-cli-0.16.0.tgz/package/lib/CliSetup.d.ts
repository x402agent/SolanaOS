import { Command } from "commander";
export declare const mainCli: Command;
export declare const initCliCmd: Command;
export declare const createCliCmd: Command;
export declare const createAppCliCmd: Command;
export declare const createReleaseCliCmd: Command;
//# sourceMappingURL=CliSetup.d.ts.map