export {};
//# sourceMappingURL=CliSetupTest.d.ts.map