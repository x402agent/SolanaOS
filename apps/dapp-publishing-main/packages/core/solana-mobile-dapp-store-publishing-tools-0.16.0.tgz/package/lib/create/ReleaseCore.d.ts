import type { Keypair, PublicKey } from "@solana/web3.js";
import type { App, Context, MetaplexFileReleaseJsonMetadata, Publisher, Release } from "../types.js";
export declare const createReleaseJson: ({ releaseDetails, appDetails, publisherDetails, }: {
    releaseDetails: Release;
    appDetails: App;
    publisherDetails: Publisher;
}, publisherAddress: PublicKey) => Promise<MetaplexFileReleaseJsonMetadata>;
type CreateReleaseInput = {
    releaseMintAddress: Keypair;
    appMintAddress: PublicKey;
    releaseDetails: Release;
    publisherDetails: Publisher;
    appDetails: App;
    priorityFeeLamports: number;
};
export declare const createRelease: ({ appMintAddress, releaseMintAddress, releaseDetails, appDetails, publisherDetails, priorityFeeLamports, }: CreateReleaseInput, { publisher, metaplex }: Context) => Promise<{
    releaseJson: MetaplexFileReleaseJsonMetadata;
    txBuilder: import("@metaplex-foundation/js").TransactionBuilder<object>;
}>;
export {};
//# sourceMappingURL=ReleaseCore.d.ts.map