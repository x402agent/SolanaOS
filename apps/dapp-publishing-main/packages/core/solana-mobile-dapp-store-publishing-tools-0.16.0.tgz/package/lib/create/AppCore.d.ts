import type { App, AppMetadata, Context } from "../types.js";
import type { PublicKey, Signer } from "@solana/web3.js";
export declare const createAppJson: (app: App, publisherAddress: PublicKey) => AppMetadata;
type CreateAppInput = {
    publisherMintAddress: PublicKey;
    mintAddress: Signer;
    appDetails: App;
    priorityFeeLamports: number;
};
export declare const createApp: ({ publisherMintAddress, mintAddress, appDetails, priorityFeeLamports }: CreateAppInput, { metaplex, publisher }: Context) => Promise<import("@metaplex-foundation/js").TransactionBuilder<object>>;
export {};
//# sourceMappingURL=AppCore.d.ts.map