import type { Metaplex, MetaplexFile } from "@metaplex-foundation/js";
import type { Keypair } from "@solana/web3.js";
import type { ReleaseJsonMetadata, AppJsonMetadata, PublisherJsonMetadata } from "./generated";
export type { ReleaseJsonMetadata } from "./generated";
export type PublisherMetadata = PublisherJsonMetadata;
export type AppMetadata = Omit<AppJsonMetadata, "image"> & {
    image: string | MetaplexFile;
};
export type MetaplexFileReleaseJsonMetadata = Omit<ReleaseJsonMetadata, "image"> & {
    image: string | MetaplexFile;
    extensions: {
        solana_dapp_store: {
            media: {
                uri: MetaplexFile;
            }[];
            files: {
                uri: MetaplexFile;
            }[];
        };
    };
};
export type Context = {
    publisher: Keypair;
    metaplex: Metaplex;
};
export type AndroidDetails = {
    android_package: string;
    min_sdk: number;
    version_code: number;
    cert_fingerprint: string;
    version: string;
    permissions: string[];
    locales: string[];
};
export type Publisher = {
    name: string;
    website: string;
    email: string;
    support_email?: string;
};
export type App = {
    name: string;
    icon?: string | MetaplexFile;
    address: string;
    android_package: string;
    urls: {
        license_url: string;
        copyright_url: string;
        privacy_policy_url: string;
        website: string;
    };
    media: ReleaseJsonMetadata["extensions"]["solana_dapp_store"]["media"];
};
export type Release = {
    address: string;
    media: ReleaseJsonMetadata["extensions"]["solana_dapp_store"]["media"];
    files: ReleaseJsonMetadata["extensions"]["solana_dapp_store"]["files"];
    android_details: AndroidDetails;
    catalog: {
        [locale: string]: {
            name: string;
            long_description: string;
            new_in_version: string;
            saga_features: string;
            short_description: string;
        };
    };
};
export type AlphaTester = {
    address: string;
    comment: string;
};
export type SolanaMobileDappPublisherPortal = {
    google_store_package: string;
    testing_instructions: string;
    alpha_testers: AlphaTester[];
};
export type LastSubmittedVersionOnChain = {
    address: string;
    version_code: number;
    apk_hash: string;
};
export type LastUpdatedVersionOnStore = {
    address: string;
};
//# sourceMappingURL=types.d.ts.map