import type { CreateNftInput, JsonMetadata, Metaplex, MetaplexFile, TransactionBuilder } from "@metaplex-foundation/js";
export declare class Constants {
    static PUBLISHING_SCHEMA_VER: string;
}
export declare const truncateAddress: (address: string) => string;
type JsonMetadataMetaplexFile = Omit<JsonMetadata, "image"> & {
    image: string | MetaplexFile;
};
export declare const mintNft: (metaplex: Metaplex, json: JsonMetadataMetaplexFile, createNftInput: Omit<CreateNftInput, "uri" | "name" | "sellerFeeBasisPoints">, priorityFeeLamports: number) => Promise<TransactionBuilder>;
export {};
//# sourceMappingURL=CoreUtils.d.ts.map