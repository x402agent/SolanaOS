import type { AppMetadata, MetaplexFileReleaseJsonMetadata } from "../types.js";
export declare const metaplexFileReplacer: (_key: any, v: any) => any;
export declare const validateApp: (appJson: AppMetadata) => true;
export declare const validateRelease: (releaseJson: MetaplexFileReleaseJsonMetadata) => true;
//# sourceMappingURL=CoreValidation.d.ts.map