import { Connection } from "@solana/web3.js";
import { SignWithPublisherKeypair } from "./types";
export declare const createAttestationPayload: (connection: Connection, sign: SignWithPublisherKeypair) => Promise<{
    attestationPayload: string;
    requestUniqueId: string;
}>;
//# sourceMappingURL=PublishCoreAttestation.d.ts.map