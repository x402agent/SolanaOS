import type { Publisher, SolanaMobileDappPublisherPortal } from "../types.js";
import { PublishSolanaNetworkInput } from "./types.js";
export type PublishSubmitInput = {
    appMintAddress: string;
    releaseMintAddress: string;
    publisherDetails: Publisher;
    solanaMobileDappPublisherPortalDetails: SolanaMobileDappPublisherPortal;
    compliesWithSolanaDappStorePolicies: boolean;
    requestorIsAuthorized: boolean;
    alphaTest?: boolean;
};
export declare const publishSubmit: (publishSolanaNetworkInput: PublishSolanaNetworkInput, { appMintAddress, releaseMintAddress, publisherDetails, solanaMobileDappPublisherPortalDetails, compliesWithSolanaDappStorePolicies, requestorIsAuthorized, alphaTest, }: PublishSubmitInput, dryRun: boolean) => Promise<void>;
//# sourceMappingURL=PublishCoreSubmit.d.ts.map