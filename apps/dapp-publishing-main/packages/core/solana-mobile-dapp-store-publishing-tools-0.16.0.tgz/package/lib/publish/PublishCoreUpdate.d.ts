import type { Publisher, SolanaMobileDappPublisherPortal } from "../types.js";
import { PublishSolanaNetworkInput } from "./types.js";
export type PublishUpdateInput = {
    appMintAddress: string;
    releaseMintAddress: string;
    publisherDetails: Publisher;
    solanaMobileDappPublisherPortalDetails: SolanaMobileDappPublisherPortal;
    compliesWithSolanaDappStorePolicies: boolean;
    requestorIsAuthorized: boolean;
    criticalUpdate: boolean;
    alphaTest?: boolean;
};
export declare const publishUpdate: (publishSolanaNetworkInput: PublishSolanaNetworkInput, { appMintAddress, releaseMintAddress, publisherDetails, solanaMobileDappPublisherPortalDetails, compliesWithSolanaDappStorePolicies, requestorIsAuthorized, criticalUpdate, alphaTest, }: PublishUpdateInput, dryRun: boolean) => Promise<void>;
//# sourceMappingURL=PublishCoreUpdate.d.ts.map