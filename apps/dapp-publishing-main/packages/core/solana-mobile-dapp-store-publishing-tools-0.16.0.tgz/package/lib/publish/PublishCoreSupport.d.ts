import type { Publisher } from "../types.js";
import { PublishSolanaNetworkInput } from "./types.js";
export type PublishSupportInput = {
    appMintAddress: string;
    releaseMintAddress: string;
    publisherDetails: Publisher;
    requestorIsAuthorized: boolean;
    requestDetails: string;
};
export declare const publishSupport: (publishSolanaNetworkInput: PublishSolanaNetworkInput, { appMintAddress, releaseMintAddress, publisherDetails, requestorIsAuthorized, requestDetails, }: PublishSupportInput, dryRun: boolean) => Promise<void>;
//# sourceMappingURL=PublishCoreSupport.d.ts.map