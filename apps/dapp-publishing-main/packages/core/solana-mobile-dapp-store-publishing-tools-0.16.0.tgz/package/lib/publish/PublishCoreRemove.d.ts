import type { Publisher } from "../types.js";
import { PublishSolanaNetworkInput } from "./types.js";
export type PublishRemoveInput = {
    appMintAddress: string;
    releaseMintAddress: string;
    publisherDetails: Publisher;
    requestorIsAuthorized: boolean;
    criticalUpdate: boolean;
};
export declare const publishRemove: (publishSolanaNetworkInput: PublishSolanaNetworkInput, { appMintAddress, releaseMintAddress, publisherDetails, requestorIsAuthorized, criticalUpdate, }: PublishRemoveInput, dryRun: boolean) => Promise<void>;
//# sourceMappingURL=PublishCoreRemove.d.ts.map